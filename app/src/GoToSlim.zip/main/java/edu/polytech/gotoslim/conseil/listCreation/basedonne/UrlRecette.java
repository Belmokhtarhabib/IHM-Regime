package edu.polytech.gotoslim.conseil.listCreation.basedonne;

public class UrlRecette {

    String url;

    public UrlRecette(String url){
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
