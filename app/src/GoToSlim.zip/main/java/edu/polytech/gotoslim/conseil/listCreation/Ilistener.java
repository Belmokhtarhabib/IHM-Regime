package edu.polytech.gotoslim.conseil.listCreation;

public interface Ilistener {
    public void onClick(Meal item);
}