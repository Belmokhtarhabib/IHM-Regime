package edu.polytech.gotoslim.RequestApi;

public class DeserialisationJson {
}
