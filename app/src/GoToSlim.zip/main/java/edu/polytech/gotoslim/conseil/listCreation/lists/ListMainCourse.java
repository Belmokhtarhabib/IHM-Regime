package edu.polytech.gotoslim.conseil.listCreation.lists;

import java.util.ArrayList;

import edu.polytech.gotoslim.R;
import edu.polytech.gotoslim.conseil.listCreation.Meal;

public class ListMainCourse extends ArrayList<Meal> {


    public ListMainCourse() {
        add(new Meal("potage tomate", R.drawable.potagetomate, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.jusbetrave, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.potagetomate, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.jusbetrave, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.potagetomate, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.jusbetrave, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.potagetomate, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.jusbetrave, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.potagetomate, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.jusbetrave, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.potagetomate, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.jusbetrave, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.potagetomate, "potageTomate"));
        add(new Meal("potage tomate", R.drawable.jusbetrave, "potageTomate"));
    }
}