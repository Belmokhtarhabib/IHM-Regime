package edu.polytech.gotoslim.conseil.listCreation;

public abstract class MealConst {
    public static final String STARTER = "starter";
    public static final String MAIN_COURSE = "main_course";
    public static final String DESERT = "desert";
    public static final String DRINK = "drink";
}

