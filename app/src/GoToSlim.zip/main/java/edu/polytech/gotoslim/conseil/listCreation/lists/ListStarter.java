package edu.polytech.gotoslim.conseil.listCreation.lists;

import java.util.ArrayList;

import edu.polytech.gotoslim.R;
import edu.polytech.gotoslim.conseil.listCreation.Meal;

public class ListStarter extends ArrayList<Meal> {

    public ListStarter(){
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
        add(new Meal("Jus de bétrave", R.drawable.jusbetrave, "betterave"));
    }
}